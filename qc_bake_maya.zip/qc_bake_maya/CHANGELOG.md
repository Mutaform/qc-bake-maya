# Changelog

## 1.2.4

Shelf icon from `icons_src/qc_bake.svg` - a real vector this time, so every
size is drawn from the source rather than resampled from a bitmap.

**Why the icon is still shipped as PNG, given Maya accepts SVG.** It does
accept it: a shelf button loads an `.svg` from disk and draws it. But it draws
it through Qt, which implements SVG Tiny - no `<mask>`. Qt ignores the element
and then paints the mask's own contents as artwork, which on this file floods
a green path across the QC BAKE text and leaves a white rectangle behind it.
Measured on a real shelf button, not assumed: 29% green, 11% white.

So the PNGs are rendered by a browser, which implements the whole spec, and
Edge ships with Windows. One render at 512 then resampled down - asking for
each size directly was a lottery, with some coming back clipped to a band.

If the mask is flattened in the source artwork, Maya can use the SVG directly
and this build step disappears.

Also corrected the README, which still described update checks as rate limited
to once every six hours; 1.2.2 made them happen on every open.

## 1.2.3

Shelf icon swapped again: the copper QC BAKE badge, replacing the flame one
introduced in 1.2.0. Same build path - `icons_src/qc_bake_source.png` through
`icons_src/make_icon.py`, which measures the corner radius (39 px this time)
and rebuilds the alpha, since the artwork is exported flat with the design
tool's canvas grey in its corners.

At 32 px "QC" reads and "BAKE" resolves to a dark bar. Being light on a dark
shelf, it stands out more than the dark badge did.

A patch rather than a minor bump: this revises the icon 1.2.0 introduced
rather than adding anything.

## 1.2.2

**Opening the panel now always checks for updates.** No timestamp, no
interval, no conditions beyond the "Check on Open" switch itself.

1.2.1 tried to be clever about this - remember when the last check happened,
skip if it was recent, but make an exception for a version that had never
checked for itself. It still produced the only outcome that matters: a tool
that knew it was out of date and said nothing, twice, on a real install.
Opening QC Bake from the shelf is a deliberate act and the moment an artist is
most willing to hear it. One small JSON request on a worker thread is not
worth outsmarting.

The rate limit survives only for `showEvent` - docking, undocking, tab
changes, layout restores - none of which is anybody asking for anything.

## 1.2.1

**A freshly installed copy stayed silent about being out of date.** Settings
live in Maya optionVars, which belong to the artist and outlive any install -
so a copy installed minutes ago inherited the previous one's "checked
recently" timestamp and skipped its own check, for up to six hours. Reported
from a real install: 1.1.4 said nothing while 1.2.0 was published. The
timestamp is now recorded together with the version it was taken from, and a
version that has not checked for itself checks regardless of the clock.

**Skip and Install sat side by side in the update banner**, one slip apart,
and they do very different things - one replaces the running tool, the other
silently hides the offer. They are now in opposite corners with the width of
the panel between them, and Install carries the weight of the action it
performs while Skip recedes.

The status strip no longer keeps saying "Checking for updates..." after the
banner has appeared with the answer.

## 1.2.0

New shelf icon: the QC Bake badge - flame over a copper name band - replacing
the plain flame.

The source art was exported flat, RGB with no alpha and its rounded corners
filled with the design tool's canvas grey, which on Maya's lighter shelf would
have shown as four dark wedges around the badge. The alpha is therefore rebuilt
at build time: `icons_src/make_icon.py` measures the badge's corner radius and
draws a clean anti-aliased rounded rectangle, rather than making one colour
transparent - which would also have punched holes anywhere inside the badge
sharing that grey.

The previous flame generator is gone. It wrote into the same files, so leaving
it in place meant anyone who ran it would silently put the old icon back.

## 1.1.4

Working-folder layout. Nothing in the tool itself changed.

The project holds three folders and no others: `Git/` is the repository and
contains only files the repository actually tracks, `Zip Addon/` holds exactly
one archive - the current release - and `Dev/` takes everything else.

`tools/build_release.ps1` writes its output into `Dev/` when run by hand, and
into the repository when run on CI, where the workflow has to publish `pages/`
from the checkout. The two tests that look for a built archive check both
places rather than assuming one.

## 1.1.3

README rewritten in Russian and cut roughly in half. What an artist needs -
what the tool does, how to install it, what each button does, how updates
work - stays; the internal detail about release layout, icon sources and the
repository tree is gone, since it described the workshop rather than the tool.

Version bumped even though nothing functional changed, so that a version
number keeps identifying one exact archive: the README ships inside the zip.

## 1.1.2

Licensing and housekeeping. No functional change to the tool.

- **The LICENSE file was a placeholder.** It carried GPL-2.0-or-later, pointed
  at `qc_bake/blender_manifest.toml` - a file that belongs to the Blender
  repository and does not exist here - and contained an instruction to replace
  itself before public release, which had not happened. QC Bake for Maya is now
  explicitly Copyright (c) 2026 Mutaform Studio, all rights reserved. The
  Blender edition is GPL because Blender's Python API requires that of add-ons;
  Maya imposes no equivalent condition, and the same author licenses this
  edition on its own terms.
- Documentation examples no longer hard-code one machine's folder layout. They
  read `C:\path\to\qc-bake-maya`, which is obviously a placeholder rather than
  a path that happens to exist on exactly one computer.
- Removed an empty `tests/__init__.py`. Nothing imported `tests` as a package.

## 1.1.1

**The release archive did not contain the shelf icon.** It sat beside the
package rather than inside it, so the build skipped it: every install from a
published zip would have silently worn a stock Maya icon, and an update - which
swaps the package folder and nothing else - would never have put it right. The
rendered PNGs now live in `qc_bake_maya/resources/`, inside the package, so
they travel with both. The artwork and its generator stay outside, in
`icons_src/`, since only whoever redraws the icon needs them.

Found by a new test, `tests/test_install_maya.py`, which unpacks the published
archive into a folder that has never held the tool and installs from there
through the real drag-and-drop entry point - then checks the module file, the
shelf button, the icon on it, the panel, its subscriptions, and that Create
Namepair actually renames something. Nothing in it reaches back into the
development repository, which is why it caught this at all.

## 1.1.0

**Updates.** Maya has no add-on repository - a `.mod` is a path pointer,
`moduleInfo` knows nothing about versions, and the Autodesk App Store means a
bundle and a review queue. So QC Bake now checks a manifest published on
GitHub Pages and says at the top of the panel when a newer release exists. It
never installs on its own.

- Pressing **Install** downloads the archive, checks it against the digest the
  manifest declared, unpacks it, swaps it into place and reloads the package
  without restarting Maya. The previous version is kept until the new one has
  actually imported, so a broken release restores itself.
- The check runs on a worker thread, at most once every six hours, and stays
  quiet on failure unless it was asked for by hand - a studio proxy that
  swallows the request must never stall Maya or nag every time the panel opens.
- Refusals that matter: manifests served or downloading over plain http, a
  manifest for a different tool, a version string that is not a version, an
  archive that is not a zip, an archive that unpacks outside its own folder,
  and an archive whose contents disagree with the version advertised.
- `tools/build_release.ps1` generates `version.json` beside the zip, and
  `.github/workflows/pages.yml` publishes both. The manifest is built, never
  hand-written, so it cannot drift from the archive it describes.

**A shelf icon of its own.** A flame, drawn as flat vector in three layers,
replacing the borrowed Maya resource. Source and generator in `icons/src/`.
The studio mark was tried in the icon and dropped: at the 32 pixels a shelf
button actually draws, it either crowded the flame or turned into a dark
smudge that read as dirt rather than as a logo.

## 1.0.4

Fixes the blank panel and the `RuntimeError: Internal C++ object already
deleted` behind it. One session had accumulated **132 scriptJobs aimed at
twelve destroyed panels**, each firing on every selection change.

The cause was ownership. Subscriptions were installed by a panel, bound to
that panel's own methods, and tracked in a registry on the class. Maya does
not reliably tell a widget when its workspaceControl is destroyed, so the jobs
outlived their panels - and reloading the package gave the class a fresh
registry while Maya carried on running the old jobs, which nothing could then
find or stop.

- Subscriptions now belong to the module and are bound to module functions
  that look up whichever panel is current, so a job can never hold a dead one.
- Which jobs exist is read back from Maya rather than remembered. Keeping a
  second copy of that list meant two sources of truth that drifted: a panel
  would believe its subscriptions were gone while eleven of them ran happily,
  and reinstall on every tick. It also makes jobs from a previous generation
  findable, which is what makes a reload survivable.
- Nothing escapes a subscription callback any more. Maya *disables* a
  scriptJob whose callback raises - which is how those orphans eventually died,
  one error line each - so a single unhandled exception in a refresh would have
  silently unsubscribed the panel and frozen it for the session.
- `_refresh_selection` is guarded like `refresh`. It was the one callback
  reaching for widgets with no protection, and it was line 506 in the report.
- A panel being replaced no longer tears down its successor's wiring, and a
  panel is no longer wired up before it is reachable - a race that left the
  new subscriptions dead on arrival.
- `close()` stops the subscriptions; call it before reloading the package.

## 1.0.3

- **Maya's auto-numbering no longer hides an object from the tool.**
  Duplicating geometry is how a Maya artist makes a variant, and Maya names the
  copy by appending a digit - so `Cub_low` becomes `Cub_low2`, which a plain
  suffix test does not recognise. Such an object dropped out of every list QC
  Bake builds: not organised, not counted, not shown or hidden, and left
  sitting inside whatever bake group it happened to be in. Suffix matching now
  accepts a trailing number, so `Cub_low2` is a low with the base `Cub`, gets
  its own `Bake_Cub` group and is tagged red for having no high. The leading
  underscore keeps this from over-reaching: `pillow2` is still not a low.
- **A bake group holding an unnamed object no longer reports itself healthy.**
  An object with no bake suffix is not ours to move, so it stays where it is -
  but the group is now tagged red and the run says which objects they are.
  Previously such a group stayed green while carrying geometry that would end
  up in the bake.

## 1.0.2

Fixes the "buttons are dead" report: a second panel was left on screen holding
no scriptJobs, so it never saw a selection change and its buttons stayed greyed
out no matter what was picked. It is now impossible to end up with two.

- **Exactly one panel, always.** Panels are tracked in a weak registry, and
  `show()` destroys any copy that did not come through it - a screenshot
  helper, a pasted snippet, a half-finished reload. Strays are hidden at once
  rather than on the next event-loop trip.
- **A panel that loses its subscriptions re-arms itself**, rather than sitting
  there looking normal and noticing nothing. Checked when the panel is shown,
  and every two seconds by a timer that only asks whether the jobs still exist
  - the scene is never rescanned on a timer.
- **A greyed-out button now says why.** A live hint under the primary buttons
  reports what QC Bake can see and what each button would do with it: nothing
  selected, one mesh when two are needed, which of two becomes the high, or a
  selection that holds no polygon meshes at all. The Visibility section says
  the same when nothing has been named yet.

Also added `tests/test_panel_maya.py`, covering all of the above plus the
1.0.1 fixes.

## 1.0.1

Fixes for four defects found the first time the tool met a real scene.

- **The panel could show one instance while the code held another.** `show()`
  was also the uiScript Maya runs when it rebuilds the workspaceControl, and
  it began by deleting that very control - so restoring the dock replaced the
  panel behind the artist's back, and any message on screen belonged to a
  discarded widget. `show()` now surfaces a live panel instead of rebuilding
  it, and only clears a control when nothing is alive inside it.
- **An exception in a command never reached the artist.** A PySide slot that
  raises prints to stdout and returns quietly, so the panel looked fine while
  the action had not run - and with no Script Editor open there was nothing to
  see at all. Commands now report failures in the status strip either way.
- **"Nothing to organize" was dressed up as an error.** Pressing a Collection
  Layout button before anything is renamed is a normal thing to do. It is now
  a warning that says to run Create Namepair first, and counts the meshes it
  looked at.
- **A mesh named `Low`, `High` or `Bake_Group` was adopted as that group**, and
  the rest of the scene parented inside the geometry. Transforms carrying a
  mesh are no longer treated as groups, and the clash is reported by name.

## 1.0.0

First release. A port of the QC Bake Blender extension 2.0.0 to Maya 2025,
with feature parity: namepair creation, high/low swapping, role visibility,
bake-group reduction with a reversible backup, and both collection layouts.

Behaviour that differs from the Blender original, by design:

- Settings are stored in optionVars rather than in the scene, so a naming
  convention follows the artist instead of the file.
- Show/hide runs through display layers, which leaves each object's own
  visibility attribute untouched.
- "Hide After Renaming" parks objects with `lodVisibility`, the viewport-only
  switch, matching what Blender's `hide_set` did.
- Collections became groups, under a single `Bake_Group` head.
- Group health is shown as a real outliner colour rather than one of Blender's
  eight fixed collection tags.

New, because Maya needed it:

- **Count Smooth Preview** - `polyEvaluate` does not see smooth mesh preview,
  so a high poly being viewed on "3" would otherwise read as its base cage and
  lose the high/low comparison.
- **Track Selection Order** - Maya does not record selection order unless asked
  to, so without it there is no "active object" to use as the low poly in group
  mode.
- Renames keep referenced objects inside their namespace, and every lookup uses
  full DAG paths so two same-named nodes in different groups are still reported
  as a clash.
- Node names are validated before use. Maya silently rewrites an illegal name
  rather than refusing it, so a rename that "worked" can still be wrong.
